Peace Synthesizer Framework version 0.03
for Linux 64bits Compile in Ubuntu

Usage
 
type 
./PeaceSynthesizerFramework 
in terminal for interactive console

type 
./install.sh
in terminal for install pre-required dependency

