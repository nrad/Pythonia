sudo apt-get install libportaudio0 libportaudio2 libportaudiocpp0 portaudio19-dev
