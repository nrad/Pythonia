##\example tu_001a_makesound.py
#Easiest way to generate sound!!
#
#\n\n <small>Click on each function for more detail </small>\n

import peaceaudio

peaceaudio.init_peaceaudio_easy()
peaceaudio.beep()


